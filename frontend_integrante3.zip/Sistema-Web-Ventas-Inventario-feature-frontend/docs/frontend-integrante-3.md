# Entrega Frontend — Integrante 3

Se incorporó el tema responsive común al proyecto existente, manteniendo JSP y rutas del backend.

## Archivos agregados
- `SistemaWebVentasInventario/src/main/webapp/assets/css/frontend.css`
- `SistemaWebVentasInventario/src/main/webapp/assets/js/frontend.js`

## Pantallas conectadas al contrato existente
- Login: `GET/POST /login` (`usuario`, `password`)
- Dashboard: `GET /dashboard`
- Listado: `GET /productos`
- Registro: `GET/POST /productos/crear` (`nombre`, `descripcion`, `precio`, `stock`, `csrfToken`)
- Edición: `GET /productos/actualizar?id=...` y `POST /productos/actualizar`
- Desactivación: `POST /productos/eliminar` (`id`, `csrfToken`)
- Salida: `POST /logout`

Las vistas se mantienen en los JSP ya existentes y se enlazan al CSS/JS por el contexto de aplicación. El backend conserva la validación de sesión, permisos y CSRF. La confirmación de eliminación se conecta mediante `data-confirm` y `frontend.js` en el formulario correspondiente.

## Validación
La hoja de estilos adapta contenedores, navegación, formularios y tablas a pantallas pequeñas. Las tablas pueden desplazarse horizontalmente en móviles para evitar desbordar la página.

## Ejecución
Importar el módulo Maven `SistemaWebVentasInventario` en NetBeans, configurar PostgreSQL/Tomcat 10.1 según el README del backend y ejecutar la aplicación. El contexto esperado es `/SistemaWebVentasInventario`.

## Correcciones de integración (04/11/2026)
- Se agregó un contenedor `.table-wrap` al listado para permitir desplazamiento horizontal en pantallas pequeñas.
- La confirmación de eliminación usa el listener compartido de `frontend.js`, sin `onsubmit` inline.
- Se conserva el botón Eliminar exclusivamente para ADMINISTRADOR, junto con el token CSRF original.
- Se ajustó el estilo de botón destructivo para que no herede el color azul del tema general.
- Se corrigieron las referencias de `password`, PostgreSQL y el estado de integración en el contrato.
- Los estilos originales de cada JSP se conservan deliberadamente para no alterar su comportamiento visual sin pruebas de navegador; la unificación completa queda como mejora opcional.

**Precaución Git:** Este ZIP es una copia completa del repositorio, no un parche aislado. Para fusionar con `feature/backend`, aplicar preferentemente solo los JSP, CSS, JS y documentación cambiados. No sobrescribir DAO, servlets, configuración ni scripts SQL de la rama backend vigente.

**Validación pendiente:** compilación Maven, prueba visual en navegador, inicio de sesión, CRUD, CSRF y permisos con ADMINISTRADOR/OPERADOR sobre el WAR resultante.
