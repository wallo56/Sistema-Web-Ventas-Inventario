/* Interacciones no intrusivas: confirmaciones y validación del navegador. */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      const message = form.dataset.confirm || "¿Deseas continuar?";
      if (!window.confirm(message)) event.preventDefault();
    });
  });

  document.querySelectorAll('input[type="number"][min]').forEach((input) => {
    input.addEventListener("input", () => {
      if (input.validity.badInput || input.validity.rangeUnderflow || input.validity.stepMismatch) {
        input.setCustomValidity("Revisa el valor ingresado.");
      } else {
        input.setCustomValidity("");
      }
    });
  });
});
